<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { page } from '$app/stores';
  import StageBadge from '$lib/components/StageBadge.svelte';
  import CycleStageBar from '$lib/components/CycleStageBar.svelte';
  import { relativeTime, formatDuration } from '$lib/util/relative-time';
  import { withWorkspace } from '$lib/stores/workspace';
  import MarkdownRenderer from '$lib/components/MarkdownRenderer.svelte';
  import {
    MARKDOWN_FIELDS,
    ALWAYS_STRIP,
    stripMarkdownFields,
    markdownSections,
    resolveAgentResponseContent,
    agentRunSections,
    phaseMetaStats,
    type AgentRunSection,
  } from '$lib/util/phase-render';

  const TERMINAL = new Set(['completed', 'failed', 'killed']);
  const PHASES = ['audit', 'plan', 'assign', 'execute', 'test', 'review', 'gate', 'release', 'learn'] as const;
  const FILES = ['tests', 'git', 'pr', 'approval-pending', 'approval-decision'] as const;
  type Phase = (typeof PHASES)[number];
  type FileName = (typeof FILES)[number];
  type Tab = 'overview' | 'items' | 'agents' | 'scoring' | 'events' | 'phases' | 'files' | 'logs';
  type LogName = 'cli-stdout' | 'tests-raw';
  type LogViewMode = 'structured' | 'raw';

  let id = $derived($page.params.id);

  let cycle: any = $state(null);
  let scoring: any = $state(null);
  let loading = $state(true);
  let error: string | null = $state(null);

  let activeTab: Tab = $state('items');

  // Live sprint view — polls /cycles/:id/sprint every 3s while cycle is
  // running. Execute phase writes to the sprint file incrementally per
  // item completion, so this is the only surface that shows real-time
  // per-item progress during the long execute phase. Same beautiful kanban
  // used on /sprints/[version].
  let sprint: any = $state(null);
  let sprintLoading = $state(false);
  let sprintError: string | null = $state(null);
  let sprintPollTimer: ReturnType<typeof setInterval> | null = null;

  async function loadSprint() {
    if (!id) return;
    sprintLoading = true;
    try {
      const res = await fetch(`/api/v5/cycles/${id}/sprint`);
      if (res.ok) {
        const json = await res.json();
        sprint = json.sprint ?? json;
        sprintError = null;
      } else if (res.status === 404) {
        sprint = null;
        sprintError = 'Sprint not generated yet — still in audit/plan phase';
      } else {
        sprintError = `HTTP ${res.status}`;
      }
    } catch (e) {
      sprintError = String(e);
    } finally {
      sprintLoading = false;
    }
    // Also refresh the cycle summary (cost/tests/stage) and agents on each tick.
    // The server emits 404 + body with cycleInProgress:true for cycles that
    // exist but haven't written cycle.json yet — treat those as live data.
    try {
      const res = await fetch(`/api/v5/cycles/${id}`);
      if (res.ok) {
        cycle = await res.json();
      } else if (res.status === 404) {
        const body = await res.json().catch(() => null);
        if (body?.cycleInProgress) cycle = body;
      }
    } catch {}
    loadAgents();
  }

  // Agents tab state — live list of every agent run in the cycle with cost,
  // duration, per-phase aggregates, and response snippets. Polled alongside
  // the sprint endpoint so the Cost stat updates live during execute.
  let agentsData: any = $state(null);
  let agentsLoading = $state(false);
  async function loadAgents() {
    if (!id) return;
    agentsLoading = true;
    try {
      const res = await fetch(`/api/v5/cycles/${id}/agents`);
      if (res.ok) agentsData = await res.json();
    } catch {} finally { agentsLoading = false; }
  }

  function startSprintPoll() {
    if (sprintPollTimer) return;
    loadSprint();
    sprintPollTimer = setInterval(loadSprint, 3000);
  }
  function stopSprintPoll() {
    if (sprintPollTimer) { clearInterval(sprintPollTimer); sprintPollTimer = null; }
  }

  // Events
  let events: any[] = $state([]);
  let eventsSince = 0;
  let eventSource: EventSource | null = null;
  let sseReconnectTimer: ReturnType<typeof setTimeout> | null = null;
  let sseConnected = $state(false);

  // Phases (lazy)
  let openPhases: Record<string, boolean> = $state({});
  let phaseData: Record<string, any> = $state({});
  let phaseLoading: Record<string, boolean> = $state({});
  let phaseError: Record<string, string | null> = $state({});

  // Files
  let activeFile: FileName = $state('tests');
  let fileData: Record<string, any> = $state({});
  let fileLoading: Record<string, boolean> = $state({});
  let fileError: Record<string, string | null> = $state({});

  // ── Logs tab ──────────────────────────────────────────────────────────────
  let activeLog: LogName = $state('cli-stdout');
  let logViewMode: LogViewMode = $state('raw');
  let logText: Record<LogName, string | null> = $state({ 'cli-stdout': null, 'tests-raw': null });
  let logLoading: Record<LogName, boolean> = $state({ 'cli-stdout': false, 'tests-raw': false });
  let logError: Record<LogName, string | null> = $state({ 'cli-stdout': null, 'tests-raw': null });
  let logAutoScroll = $state(true);
  let logStreamSource: EventSource | null = null;
  let logStreamLines: string[] = $state([]);
  let logStreamConnected = $state(false);

  const LOG_LEVEL_RE = /\b(WARN|ERROR|FATAL|FAILED|ERR)\b/i;
  const REPEAT_LINE_RE = /^\[(\d+)\/(\d+)\]/;

  interface StructuredLine {
    raw: string;
    level: 'error' | 'warn' | 'info';
    collapsed: boolean;
  }

  function parseLogLines(text: string): StructuredLine[] {
    const lines = text.split('\n').filter(l => l.length > 0);
    const result: StructuredLine[] = [];
    let repeatBuf: string[] = [];

    function flushRepeat() {
      if (repeatBuf.length === 0) return;
      if (repeatBuf.length === 1) {
        result.push({ raw: repeatBuf[0]!, level: 'info', collapsed: false });
      } else {
        result.push({ raw: `[${repeatBuf.length} similar lines] ${repeatBuf[repeatBuf.length - 1]}`, level: 'info', collapsed: true });
      }
      repeatBuf = [];
    }

    for (const line of lines) {
      if (REPEAT_LINE_RE.test(line)) {
        repeatBuf.push(line);
        continue;
      }
      flushRepeat();
      const m = LOG_LEVEL_RE.exec(line);
      const level: StructuredLine['level'] = m
        ? (/error|fatal|failed|err/i.test(m[0]) ? 'error' : 'warn')
        : 'info';
      result.push({ raw: line, level, collapsed: false });
    }
    flushRepeat();
    return result;
  }

  async function loadLog(name: LogName) {
    activeLog = name;
    teardownLogStream();
    logStreamLines = [];
    logText[name] = null;
    logLoading[name] = true;
    logError[name] = null;
    try {
      const res = await fetch(withWorkspace(`/api/v5/cycles/${id}/logs/${name}`));
      if (res.ok) {
        logText[name] = await res.text();
      } else if (res.status === 404) {
        logText[name] = null;
      } else {
        logError[name] = `HTTP ${res.status}`;
      }
    } catch (e) {
      logError[name] = String(e);
    } finally {
      logLoading[name] = false;
    }
    if (!isTerminal) startLogStream(name);
  }

  function startLogStream(name: LogName) {
    teardownLogStream();
    try {
      const es = new EventSource(`/api/v5/cycles/${id}/logs/${name}/stream`);
      logStreamSource = es;
      es.onopen = () => { logStreamConnected = true; };
      es.onmessage = (e: MessageEvent) => {
        try {
          const parsed = JSON.parse(e.data as string) as { line?: string; done?: boolean };
          if (parsed.done) { teardownLogStream(); return; }
          if (typeof parsed.line === 'string') {
            logStreamLines = [...logStreamLines, parsed.line];
            if (logAutoScroll) {
              requestAnimationFrame(() => {
                const el = document.getElementById('log-raw-pre');
                if (el) el.scrollTop = el.scrollHeight;
              });
            }
          }
        } catch { /* ignore parse errors */ }
      };
      es.onerror = () => {
        logStreamConnected = false;
        es.close();
        logStreamSource = null;
      };
    } catch { /* EventSource unavailable */ }
  }

  function teardownLogStream() {
    if (logStreamSource) { logStreamSource.close(); logStreamSource = null; }
    logStreamConnected = false;
  }

  // ── end Logs tab ──────────────────────────────────────────────────────────
  let stage = $derived(cycle?.stage ?? cycle?.result?.stage ?? cycle?.currentStage ?? 'unknown');
  let isTerminal = $derived(TERMINAL.has(String(stage).toLowerCase()));

  /** Phase ordering for sub-phase indicator. */
  const PHASE_ORDER = ['audit', 'plan', 'assign', 'execute', 'test', 'review', 'gate', 'release', 'learn'];

  /**
   * The currently-active internal phase. cycle.stage reports the internal
   * phase directly (e.g. "execute", "audit") rather than a macro stage,
   * so this is just a normalized read with fallbacks for terminal states.
   */
  let activePhase = $derived.by(() => {
    if (isTerminal) return null;
    const s = String(stage).toLowerCase();
    if (PHASE_ORDER.includes(s)) return s;
    // Fallback: macro-stage → first internal phase of that macro
    if (s === 'plan') return 'audit';
    if (s === 'stage') return 'assign';
    if (s === 'run') return 'execute';
    if (s === 'verify') return 'test';
    if (s === 'commit') return 'review';
    return null;
  });

  /**
   * Phases that have finished. Includes every phase preceding activePhase in
   * PHASE_ORDER (so they're guaranteed done) PLUS any phase that has agent
   * runs and is NOT the active phase.
   */
  let completedPhases = $derived.by(() => {
    const active = activePhase;
    if (!active) {
      // Terminal — every phase that has runs is complete
      if (!agentsData?.runs) return [];
      const seen = new Set<string>();
      for (const r of agentsData.runs) if (r?.phase) seen.add(String(r.phase));
      return PHASE_ORDER.filter((p) => seen.has(p));
    }
    const activeIdx = PHASE_ORDER.indexOf(active);
    if (activeIdx < 0) return [];
    return PHASE_ORDER.slice(0, activeIdx);
  });

  /** Now-playing strip: latest in-flight agent (or most recent if terminal). */
  let currentAgent = $derived.by(() => {
    if (!agentsData?.runs?.length) return null;
    const runs = agentsData.runs as any[];
    return runs[runs.length - 1];
  });

  async function loadInitial() {
    loading = true;
    error = null;
    try {
      const [cRes, sRes] = await Promise.all([
        fetch(withWorkspace(`/api/v5/cycles/${id}`)),
        fetch(withWorkspace(`/api/v5/cycles/${id}/scoring`)),
      ]);
      if (cRes.ok) {
        cycle = await cRes.json();
      } else if (cRes.status === 404) {
        // Server returns 404 + cycleInProgress:true for cycles that exist
        // but haven't written cycle.json yet. Honour that contract so the
        // detail page can render the live feed while the cycle is running.
        const body = await cRes.json().catch(() => null);
        if (body?.cycleInProgress) {
          cycle = body;
        } else {
          throw new Error(`cycle: HTTP ${cRes.status}`);
        }
      } else {
        throw new Error(`cycle: HTTP ${cRes.status}`);
      }
      if (sRes.ok) {
        scoring = await sRes.json();
      } else if (sRes.status !== 404) {
        // non-fatal
        scoring = null;
      }
      ensureSseSubscription();
    } catch (e) {
      error = String(e);
    } finally {
      loading = false;
    }
  }

  async function loadEvents() {
    // Historical bootstrap — fetched once on mount and on manual refresh.
    try {
      const res = await fetch(withWorkspace(`/api/v5/cycles/${id}/events?since=${eventsSince}`));
      if (!res.ok) return;
      const json = await res.json();
      const list = Array.isArray(json) ? json : (json.events ?? []);
      if (list.length > 0) {
        // Newest first
        events = [...list.slice().reverse(), ...events];
        eventsSince += list.length;
      }
    } catch {
      // ignore
    }
  }

  function ensureSseSubscription() {
    if (eventSource || isTerminal) return;
    try {
      const es = new EventSource('/api/v5/stream');
      eventSource = es;
      es.onopen = () => { sseConnected = true; };
      es.onmessage = (e) => {
        try {
          const parsed = JSON.parse(e.data);
          if (parsed?.type !== 'cycle_event') return;
          const data = parsed.data ?? {};
          if (data.cycleId !== id) return;
          // Prepend (most recent first)
          events = [data.payload ?? data, ...events];
          eventsSince += 1;
        } catch { /* ignore */ }
      };
      es.onerror = () => {
        sseConnected = false;
        es.close();
        eventSource = null;
        if (!isTerminal) {
          sseReconnectTimer = setTimeout(() => ensureSseSubscription(), 3000);
        }
      };
    } catch {
      // EventSource unavailable — fall back silently.
    }
  }

  function teardownSse() {
    if (sseReconnectTimer) { clearTimeout(sseReconnectTimer); sseReconnectTimer = null; }
    if (eventSource) { eventSource.close(); eventSource = null; }
    sseConnected = false;
  }

  function setTab(t: Tab) {
    activeTab = t;
    // Events are bootstrapped on mount; allow a manual refresh if tab is
    // clicked and list is still empty (e.g. mount fetch raced with cycle start).
    if (t === 'events' && events.length === 0) {
      loadEvents();
    }
    if (t === 'overview') {
      loadPlan();
    }
    if (t === 'logs' && logText[activeLog] === null && !logLoading[activeLog]) {
      loadLog(activeLog);
    }
  }

  async function togglePhase(phase: Phase) {
    openPhases[phase] = !openPhases[phase];
    if (openPhases[phase] && phaseData[phase] === undefined) {
      phaseLoading[phase] = true;
      phaseError[phase] = null;
      try {
        const res = await fetch(withWorkspace(`/api/v5/cycles/${id}/phases/${phase}`));
        if (res.status === 404) {
          phaseData[phase] = null;
        } else if (!res.ok) {
          phaseError[phase] = `HTTP ${res.status}`;
        } else {
          phaseData[phase] = await res.json();
        }
      } catch (e) {
        phaseError[phase] = String(e);
      } finally {
        phaseLoading[phase] = false;
      }
    }
  }

  async function loadFile(name: FileName) {
    activeFile = name;
    if (fileData[name] !== undefined) return;
    fileLoading[name] = true;
    fileError[name] = null;
    try {
      const res = await fetch(withWorkspace(`/api/v5/cycles/${id}/files/${name}`));
      if (res.status === 404) {
        fileData[name] = null;
      } else if (!res.ok) {
        fileError[name] = `HTTP ${res.status}`;
      } else {
        fileData[name] = await res.json();
      }
    } catch (e) {
      fileError[name] = String(e);
    } finally {
      fileLoading[name] = false;
    }
  }

  function pretty(value: unknown): string {
    try {
      return JSON.stringify(value, null, 2);
    } catch {
      return String(value);
    }
  }

  // MARKDOWN_FIELDS, ALWAYS_STRIP, stripMarkdownFields, markdownSections,
  // resolveAgentResponseContent, agentRunSections, and phaseMetaStats are
  // all imported from $lib/util/phase-render — see that module for documentation.

  function costFraction(cost?: number | null, budget?: number | null): number {
    if (cost == null || budget == null || budget <= 0) return 0;
    return Math.min(1, cost / budget);
  }

  $effect(() => {
    // Close SSE once cycle reaches terminal stage
    void stage;
    if (isTerminal) teardownSse();
  });

  // Auto-expand the phase panel that matches the current cycle stage.
  // Mapping: plan/stage → audit+plan, run → execute, verify → test,
  // review → review, commit → gate, completed → release+learn
  const STAGE_TO_PHASES: Record<string, Phase[]> = {
    plan:      ['audit', 'plan'],
    stage:     ['audit', 'plan'],
    run:       ['execute'],
    verify:    ['test'],
    review:    ['review'],
    commit:    ['gate'],
    completed: ['release', 'learn'],
  };

  $effect(() => {
    const key = String(stage).toLowerCase();
    const phases = STAGE_TO_PHASES[key];
    if (phases) {
      for (const p of phases) {
        if (!openPhases[p]) openPhases[p] = true;
      }
    }
  });

  onMount(() => {
    loadInitial();
    loadFile('tests');
    // Bootstrap event history immediately so the Events tab has data before it
    // is clicked, and the count badge shows a meaningful number on mount.
    loadEvents();
    // Start the live sprint poll immediately — this drives the Items tab
    // which is the default on load. Auto-stops when the cycle is terminal.
    startSprintPoll();
  });

  onDestroy(() => {
    teardownSse();
    stopSprintPoll();
    teardownLogStream();
  });

  // Auto-stop the sprint poll and log stream once the cycle hits a terminal stage.
  $effect(() => {
    void stage;
    if (isTerminal) { stopSprintPoll(); teardownLogStream(); }
  });

  // Sprint Plan (from /api/v5/cycles/:id/plan) — loaded lazily when Overview tab is active
  let planData: any = $state(null);
  let planLoading = $state(false);
  let planError: string | null = $state(null);
  let planExpanded = $state(false);

  async function loadPlan() {
    if (!id || planData !== null) return;
    planLoading = true;
    try {
      const res = await fetch(`/api/v5/cycles/${id}/plan`);
      if (res.ok) {
        planData = await res.json();
        planError = null;
      } else if (res.status === 404) {
        planData = null;
        planError = null; // pre-migration cycle, not an error
      } else {
        planError = `HTTP ${res.status}`;
      }
    } catch (e) {
      planError = String(e);
    } finally {
      planLoading = false;
    }
  }

  // Overview helpers
  let costUsd = $derived(cycle?.cost?.totalUsd ?? cycle?.costUsd ?? cycle?.cost?.usd ?? cycle?.budget?.spentUsd ?? null);
  let budgetUsd = $derived(cycle?.cost?.budgetUsd ?? cycle?.budgetUsd ?? cycle?.budget?.limitUsd ?? cycle?.budget?.budgetUsd ?? null);
  let testsPassed = $derived(cycle?.testsPassed ?? cycle?.tests?.passed ?? null);
  let testsTotal = $derived(cycle?.testsTotal ?? cycle?.tests?.total ?? null);
  let prUrl = $derived(cycle?.prUrl ?? cycle?.pr?.url ?? null);
  let branch = $derived(cycle?.branch ?? cycle?.git?.branch ?? null);
  let commitSha = $derived(cycle?.commitSha ?? cycle?.git?.commitSha ?? cycle?.git?.sha ?? null);
  let durationMs = $derived(cycle?.durationMs ?? null);
  let killSwitch = $derived(cycle?.killSwitch ?? cycle?.kill ?? null);
  let scoringResult = $derived(scoring?.result ?? scoring ?? null);
</script>

<svelte:head><title>Cycle {id?.slice(0, 8) ?? ''} — AgentForge</title></svelte:head>

<div class="page-header">
  <div>
    <nav class="breadcrumb">
      <a href="/cycles">← Cycles</a>
    </nav>
    <h1 class="page-title">
      Cycle <span class="mono">{id?.slice(0, 8)}</span>
      {#if cycle}<StageBadge stage={stage} />{/if}
    </h1>
    <p class="page-subtitle">
      {#if cycle?.sprintVersion}{cycle.sprintVersion} · {/if}
      {#if cycle?.startedAt}started {relativeTime(cycle.startedAt)}{/if}
    </p>
  </div>
</div>

{#if loading}
  <div class="card">
    <div class="skeleton" style="height:32px;margin-bottom:12px;"></div>
    <div class="skeleton" style="height:32px;margin-bottom:12px;"></div>
    <div class="skeleton" style="height:32px;"></div>
  </div>
{:else if error}
  <div class="error-banner">
    <div>Failed to load cycle: <code>{error}</code></div>
    <button class="btn btn-ghost btn-sm" onclick={loadInitial}>Retry</button>
  </div>
{:else if cycle}
  <div class="stage-bar-sticky">
    <CycleStageBar
      stage={stage}
      costUsd={costUsd}
      budgetUsd={budgetUsd}
      startedAt={cycle?.startedAt ?? null}
      isTerminal={isTerminal}
      activePhase={activePhase}
      completedPhases={completedPhases}
    />
    {#if !isTerminal && currentAgent}
      <div class="now-playing" title="Most recent agent run">
        <span class="np-dot"></span>
        <span class="np-phase">{currentAgent.phase}</span>
        <span class="np-sep">·</span>
        <span class="np-agent">{currentAgent.agentId}</span>
        {#if currentAgent.model}
          <span class="np-badge np-model np-{currentAgent.model}">{currentAgent.model}</span>
        {/if}
        {#if currentAgent.effort}
          <span class="np-badge np-effort">{currentAgent.effort}</span>
        {/if}
        {#if currentAgent.costUsd != null}
          <span class="np-sep">·</span>
          <span class="np-cost">${Number(currentAgent.costUsd).toFixed(4)}</span>
        {/if}
        {#if currentAgent.durationMs != null}
          <span class="np-sep">·</span>
          <span class="np-duration">{(currentAgent.durationMs / 1000).toFixed(1)}s</span>
        {/if}
      </div>
    {/if}
  </div>

  <nav class="tabs">
    <button class="tab" class:active={activeTab === 'items'} onclick={() => setTab('items')}>
      Items
      {#if sprint?.items}
        <span class="tab-count">{sprint.items.filter((i: any) => i.status === 'completed').length}/{sprint.items.length}</span>
      {/if}
    </button>
    <button class="tab" class:active={activeTab === 'agents'} onclick={() => setTab('agents')}>
      Agents
      {#if agentsData?.totalRuns != null}
        <span class="tab-count">{agentsData.totalRuns}</span>
      {/if}
    </button>
    <button class="tab" class:active={activeTab === 'overview'} onclick={() => setTab('overview')}>Overview</button>
    <button class="tab" class:active={activeTab === 'scoring'} onclick={() => setTab('scoring')}>Scoring</button>
    <button class="tab" class:active={activeTab === 'events'} onclick={() => setTab('events')}>
      Events
      {#if events.length > 0}
        <span class="tab-count">{events.length}</span>
      {/if}
    </button>
    <button class="tab" class:active={activeTab === 'phases'} onclick={() => setTab('phases')}>Phases</button>
    <button class="tab" class:active={activeTab === 'files'} onclick={() => setTab('files')}>Files</button>
    <button class="tab" class:active={activeTab === 'logs'} onclick={() => setTab('logs')}>
      Logs
      {#if !isTerminal && activeTab === 'logs' && logStreamConnected}
        <span class="tab-live-dot"></span>
      {/if}
    </button>
  </nav>

  <section class="tab-panel">
    {#if activeTab === 'items'}
      {#if sprintLoading && !sprint}
        <div class="card"><div class="skeleton" style="height:80px"></div></div>
      {:else if sprintError && !sprint}
        <div class="empty-state">
          <p>{sprintError}</p>
          {#if !isTerminal}
            <p class="muted" style="font-size: var(--text-xs); margin-top: var(--space-2);">The sprint file is created during the plan phase. Poll refreshes every 3s.</p>
          {:else if stage === 'killed'}
            <p class="muted" style="font-size: var(--text-xs); margin-top: var(--space-2);">This cycle was killed before a sprint was assigned.</p>
          {/if}
        </div>
      {:else if sprint?.items}
        {@const items = sprint.items}
        {@const completed = items.filter((i: any) => i.status === 'completed')}
        {@const inProgress = items.filter((i: any) => i.status === 'in_progress')}
        {@const planned = items.filter((i: any) => i.status === 'planned' || i.status === 'pending')}
        {@const failed = items.filter((i: any) => i.status === 'failed')}
        {@const killed = items.filter((i: any) => i.status === 'killed')}
        {@const pct = items.length > 0 ? Math.round((completed.length / items.length) * 100) : 0}

        <div class="card" style="margin-bottom: var(--space-5);">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: var(--space-3);">
            <div>
              <div style="font-family: var(--font-mono); font-weight: 700; font-size: var(--text-lg);">v{sprint.version ?? sprint.sprintId}</div>
              {#if sprint.title}<div class="muted" style="font-size: var(--text-sm);">{sprint.title}</div>{/if}
              {#if sprint.versionDecision}
                <div class="muted" style="font-size: var(--text-xs); margin-top: var(--space-1); font-family: var(--font-mono);">
                  {sprint.versionDecision.rationale}
                </div>
              {/if}
            </div>
            <div style="text-align: right;">
              <div style="font-size: var(--text-2xl); font-weight: 700;">{pct}%</div>
              <div class="muted" style="font-size: var(--text-xs);">{completed.length}/{items.length} items</div>
            </div>
          </div>
          <div class="cost-bar"><div class="cost-bar-fill" style="width:{pct}%"></div></div>
        </div>

        <div class="kanban">
          <div class="kanban-col">
            <div class="kanban-header">Planned <span class="kanban-count">{planned.length}</span></div>
            {#each planned as item (item.id)}
              <div class="kanban-item"><div class="item-title">{item.title}</div>{#if item.assignee}<div class="item-meta">{item.assignee}</div>{/if}</div>
            {/each}
          </div>
          <div class="kanban-col">
            <div class="kanban-header">In Progress <span class="kanban-count">{inProgress.length}</span></div>
            {#each inProgress as item (item.id)}
              <div class="kanban-item in-progress"><div class="item-title">{item.title}</div>{#if item.assignee}<div class="item-meta">{item.assignee}</div>{/if}</div>
            {/each}
          </div>
          <div class="kanban-col">
            <div class="kanban-header">Completed <span class="kanban-count">{completed.length}</span></div>
            {#each completed as item (item.id)}
              <div class="kanban-item completed"><div class="item-title">{item.title}</div>{#if item.assignee}<div class="item-meta">{item.assignee}</div>{/if}</div>
            {/each}
          </div>
          {#if failed.length > 0}
            <div class="kanban-col">
              <div class="kanban-header">Failed <span class="kanban-count">{failed.length}</span></div>
              {#each failed as item (item.id)}
                <div class="kanban-item failed"><div class="item-title">{item.title}</div>{#if item.error}<div class="item-meta">{item.error}</div>{/if}</div>
              {/each}
            </div>
          {/if}
          {#if killed.length > 0}
            <div class="kanban-col kanban-col--killed">
              <div class="kanban-header">Killed <span class="kanban-count">{killed.length}</span></div>
              {#each killed as item (item.id)}
                <div class="kanban-item killed"><div class="item-title">{item.title}</div>{#if item.assignee}<div class="item-meta">{item.assignee}</div>{/if}</div>
              {/each}
            </div>
          {/if}
        </div>
      {:else}
        <div class="empty-state">No sprint data yet.</div>
      {/if}
    {:else if activeTab === 'agents'}
      {#if !agentsData || agentsLoading && !agentsData}
        <div class="card"><div class="skeleton" style="height:80px"></div></div>
      {:else if agentsData.totalRuns === 0}
        <div class="empty-state">No agent runs yet — cycle is still in early phases.</div>
      {:else}
        {@const agents = Object.entries(agentsData.byAgent || {}).sort((a: any, b: any) => b[1].totalCostUsd - a[1].totalCostUsd)}
        <div class="card" style="margin-bottom: var(--space-5);">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="font-weight: 700; font-size: var(--text-lg);">{agents.length} agents · {agentsData.totalRuns} runs</div>
              <div class="muted" style="font-size: var(--text-sm);">Live — updates every 3s</div>
            </div>
            <div style="text-align: right;">
              <div style="font-size: var(--text-2xl); font-weight: 700;">${Number(agentsData.totalCostUsd).toFixed(2)}</div>
              <div class="muted" style="font-size: var(--text-xs);">total cost</div>
            </div>
          </div>
        </div>

        <div class="agent-grid">
          {#each agents as [agentId, stats] (agentId)}
            {@const s = stats as any}
            <div class="card agent-summary">
              <div class="agent-name">{agentId}</div>
              <div class="agent-stats">
                <div><span class="muted">runs</span> <strong>{s.runs}</strong></div>
                <div><span class="muted">cost</span> <strong>${Number(s.totalCostUsd).toFixed(3)}</strong></div>
                <div><span class="muted">duration</span> <strong>{formatDuration(s.totalDurationMs)}</strong></div>
              </div>
              <div class="agent-phases">
                {#each s.phases as p}<span class="phase-chip">{p}</span>{/each}
              </div>
            </div>
          {/each}
        </div>

        <h3 style="margin-top: var(--space-5);">Run details</h3>
        <div class="run-list">
          {#each agentsData.runs as run}
            <div class="card run-row" class:failed={run.status === 'failed'}>
              <div class="run-header">
                <span class="run-phase">{run.phase}</span>
                <span class="run-agent mono">{run.agentId}</span>
                <span class="run-status {run.status}">{run.status}</span>
                {#if run.model}<span class="model-chip {run.model.replace(/[^a-z]/gi, '')}">{run.model}</span>{/if}
                {#if run.effort}<span class="effort-chip">effort: {run.effort}</span>{/if}
                {#if run.itemId}<span class="run-item muted">{run.itemId.slice(0, 60)}</span>{/if}
              </div>
              <div class="run-meta">
                <span>${Number(run.costUsd).toFixed(4)}</span>
                <span>·</span>
                <span>{formatDuration(run.durationMs)}</span>
                {#if run.attempts}<span>·</span><span>{run.attempts} attempt{run.attempts === 1 ? '' : 's'}</span>{/if}
              </div>
              {#if run.error}
                <div class="run-error">{run.error}</div>
              {:else if run.response}
                <details class="run-response">
                  <summary>Response ({run.response.length} chars)</summary>
                  <div class="run-response-body">
                    <MarkdownRenderer content={run.response.slice(0, 4000)} />
                    {#if run.response.length > 4000}
                      <p class="run-response-truncated">… truncated — {run.response.length} chars total</p>
                    {/if}
                  </div>
                </details>
              {/if}
            </div>
          {/each}
        </div>
      {/if}
    {:else if activeTab === 'overview'}
      <div class="stat-grid">
        <div class="stat-card">
          <div class="stat-label">Stage</div>
          <div class="stat-value" style="font-size: var(--text-lg);"><StageBadge stage={stage} /></div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Duration</div>
          <div class="stat-value">{formatDuration(durationMs)}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Cost</div>
          <div class="stat-value">
            {costUsd != null ? `$${Number(costUsd).toFixed(2)}` : '—'}
          </div>
          {#if budgetUsd != null && costUsd != null}
            <div class="cost-bar" style="margin-top:var(--space-2);">
              <div class="cost-bar-fill" style="width:{costFraction(costUsd, budgetUsd) * 100}%"></div>
            </div>
            <div class="muted" style="margin-top:var(--space-1);">of ${Number(budgetUsd).toFixed(2)}</div>
          {/if}
        </div>
        <div class="stat-card">
          <div class="stat-label">Tests</div>
          <div class="stat-value">
            {testsTotal != null ? `${testsPassed ?? 0}/${testsTotal}` : '—'}
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><span class="card-title">Git</span></div>
        <dl class="kv">
          <dt>Branch</dt><dd class="mono">{branch ?? '—'}</dd>
          <dt>Commit</dt><dd class="mono">{commitSha ? String(commitSha).slice(0, 12) : '—'}</dd>
          <dt>PR</dt>
          <dd>
            {#if prUrl}
              <a href={prUrl} target="_blank" rel="noopener" class="pr-link">{prUrl} ↗</a>
            {:else}—{/if}
          </dd>
        </dl>
      </div>

      {#if killSwitch}
        <div class="card kill-card">
          <div class="card-header"><span class="card-title">Kill Switch Tripped</span></div>
          <pre class="json">{pretty(killSwitch)}</pre>
        </div>
      {/if}

      <!-- Sprint Plan collapsible section — from cycles/:id/plan (Track D) -->
      {#if planData || planLoading}
        <div class="card plan-section" style="margin-top: var(--space-4);">
          <button
            class="plan-toggle"
            onclick={() => { planExpanded = !planExpanded; loadPlan(); }}
          >
            <span class="plan-toggle-arrow">{planExpanded ? '▼' : '▶'}</span>
            <span class="plan-toggle-title">Sprint Plan</span>
            {#if planData?.version}<span class="plan-version mono">v{planData.version}</span>{/if}
            {#if planLoading}<span class="muted" style="font-size:var(--text-xs);">loading…</span>{/if}
          </button>
          {#if planExpanded && planData}
            <div class="plan-body">
              {#if planData.successCriteria && planData.successCriteria.length > 0}
                <div class="plan-field">
                  <div class="plan-label">Success Criteria</div>
                  <ul class="plan-list">
                    {#each planData.successCriteria as c}<li>{c}</li>{/each}
                  </ul>
                </div>
              {/if}
              {#if planData.versionDecision?.rationale}
                <div class="plan-field">
                  <div class="plan-label">Version Decision</div>
                  <div class="plan-text mono">{planData.versionDecision.rationale}</div>
                </div>
              {/if}
              {#if planData.ceoBrief}
                <div class="plan-field">
                  <div class="plan-label">Strategic Note</div>
                  <div class="plan-text">{planData.ceoBrief}</div>
                </div>
              {/if}
              {#if planData.risks && planData.risks.length > 0}
                <div class="plan-field">
                  <div class="plan-label">Risks ({planData.risks.length})</div>
                  <ul class="plan-list">
                    {#each planData.risks as r}<li>{r.risk}{#if r.mitigation} — <em>{r.mitigation}</em>{/if}</li>{/each}
                  </ul>
                </div>
              {/if}
              {#if planData.newHires && planData.newHires.length > 0}
                <div class="plan-field">
                  <div class="plan-label">Team Additions</div>
                  <ul class="plan-list">
                    {#each planData.newHires as h}<li>@{h.agent}{#if h.model} ({h.model}){/if}{#if h.rationale} — {h.rationale}{/if}</li>{/each}
                  </ul>
                </div>
              {/if}
            </div>
          {/if}
        </div>
      {/if}
    {/if}

    {#if activeTab === 'scoring'}
      {#if !scoringResult}
        <div class="card"><div class="empty-state">No scoring data available for this cycle.</div></div>
      {:else}
        {#if scoringResult.summary}
          <div class="card">
            <div class="card-header"><span class="card-title">Summary</span></div>
            <div class="summary">
              <MarkdownRenderer content={scoringResult.summary} />
            </div>
          </div>
        {/if}
        {#if scoringResult.warnings && scoringResult.warnings.length > 0}
          <div class="warning-banner">
            <strong>Warnings:</strong>
            <ul>
              {#each scoringResult.warnings as w}<li>{w}</li>{/each}
            </ul>
          </div>
        {/if}
        <div class="ranked-list">
          {#each (scoringResult.items ?? scoringResult.ranked ?? []) as item, i (item.id ?? i)}
            <article class="rank-card">
              <div class="rank-header">
                <span class="rank-num">#{item.rank ?? i + 1}</span>
                <h3 class="rank-title">{item.title ?? item.id ?? 'Untitled'}</h3>
                <div class="rank-stats">
                  <span class="badge muted">score {item.score ?? '—'}</span>
                  <span class="badge muted">conf {item.confidence ?? '—'}</span>
                  <span class="badge muted">${item.cost ?? item.estimatedCost ?? '—'}</span>
                  {#if item.withinBudget != null}
                    <span class="badge {item.withinBudget ? 'success' : 'danger'}">
                      {item.withinBudget ? 'within budget' : 'over budget'}
                    </span>
                  {/if}
                </div>
              </div>
              {#if item.rationale}
                <div class="rank-rationale">
                  <MarkdownRenderer content={item.rationale} />
                </div>
              {/if}
              {#if item.dependencies && item.dependencies.length > 0}
                <div class="rank-meta">
                  <strong>deps:</strong> {item.dependencies.join(', ')}
                </div>
              {/if}
              {#if item.suggestedAssignee}
                <div class="rank-meta"><strong>assignee:</strong> <span class="mono">{item.suggestedAssignee}</span></div>
              {/if}
              {#if item.suggestedTags && item.suggestedTags.length > 0}
                <div class="rank-meta">
                  {#each item.suggestedTags as tag}<span class="tag">{tag}</span>{/each}
                </div>
              {/if}
            </article>
          {/each}
        </div>
      {/if}
    {/if}

    {#if activeTab === 'events'}
      <div class="events-toolbar">
        <span class="muted">{events.length} events {!isTerminal ? (sseConnected ? '· live (SSE)' : '· connecting…') : ''}</span>
        <button class="btn btn-ghost btn-sm" onclick={loadEvents}>Refresh</button>
      </div>
      {#if events.length === 0}
        <div class="card"><div class="empty-state">No events yet.</div></div>
      {:else}
        <div class="timeline">
          {#each events as ev, i (i)}
            <div class="event-row">
              <span class="event-ts mono">{relativeTime(ev.at ?? ev.timestamp)}</span>
              <span class="badge muted">{ev.type ?? 'event'}</span>
              <pre class="event-payload">{pretty(ev)}</pre>
            </div>
          {/each}
        </div>
      {/if}
    {/if}

    {#if activeTab === 'phases'}
      <div class="phase-list">
        {#each PHASES as phase}
          {@const pData = phaseData[phase]}
          {@const pStatus = (pData as any)?.status ?? null}
          {@const pCost = (pData as any)?.costUsd ?? (pData as any)?.cost?.totalUsd ?? null}
          {@const pDuration = (pData as any)?.durationMs ?? null}
          {@const statusVariant =
            pStatus === 'completed' ? 'success'  :
            pStatus === 'failed'    ? 'danger'   :
            pStatus === 'killed'    ? 'warning'  :
            pStatus === 'running'   ? 'info'     :
            pData !== undefined     ? 'muted'    : null}
          <div class="phase-item">
            <button
              class="phase-toggle"
              class:phase-toggle--has-status={statusVariant !== null}
              class:phase-toggle--open={openPhases[phase]}
              onclick={() => togglePhase(phase)}
            >
              <span class="phase-arrow">{openPhases[phase] ? '▼' : '▶'}</span>
              {#if statusVariant !== null}
                <span class="phase-status-dot phase-status-dot--{statusVariant}"></span>
              {/if}
              <span class="phase-name">{phase}</span>
              {#if phaseLoading[phase]}
                <span class="phase-loading-hint muted">loading…</span>
              {:else if pData === null}
                <span class="phase-absent-hint muted">not present</span>
              {:else if pData !== undefined}
                <span class="phase-toggle-meta">
                  {#if pCost != null}
                    <span class="phase-cost-chip">${Number(pCost).toFixed(3)}</span>
                  {/if}
                  {#if pDuration != null}
                    <span class="phase-dur-chip">{formatDuration(pDuration)}</span>
                  {/if}
                </span>
              {/if}
            </button>
            {#if openPhases[phase]}
              <div class="phase-body">
                {#if phaseLoading[phase]}
                  <div class="skeleton" style="height:60px;"></div>
                {:else if phaseError[phase]}
                  <div class="error-msg">{phaseError[phase]}</div>
                {:else if pData == null}
                  <div class="phase-absent-body muted">No data found for this phase in the current cycle.</div>
                {:else}
                  {@const phaseSections = markdownSections(pData)}
                  {@const phaseAgentRuns = agentRunSections(pData)}
                  {@const metaOnly = stripMarkdownFields(pData)}
                  {@const metaStats = phaseMetaStats(pData)}

                  <!-- Structured stat chips (status, cost, duration, runs) -->
                  {#if metaStats.length > 0}
                    <div class="phase-meta-stats">
                      {#each metaStats as stat}
                        <div class="phase-meta-stat">
                          <span class="phase-meta-key">{stat.key}</span>
                          <span
                            class="phase-meta-val"
                            class:phase-meta-val--success={stat.key === 'status' && stat.value === 'completed'}
                            class:phase-meta-val--danger={stat.key === 'status' && stat.value === 'failed'}
                            class:phase-meta-val--warning={stat.key === 'status' && stat.value === 'killed'}
                          >{stat.value}</span>
                        </div>
                      {/each}
                    </div>
                  {/if}

                  <!-- Raw JSON for remaining structured fields (collapsed by default if stats shown) -->
                  {#if Object.keys(metaOnly).length > 0}
                    <details class="phase-json-details" open={metaStats.length === 0}>
                      <summary class="phase-json-summary">Raw metadata ({Object.keys(metaOnly).length} fields)</summary>
                      <pre class="json">{pretty(metaOnly)}</pre>
                    </details>
                  {/if}

                  <!-- Markdown prose sections (error, review, rationale, retrospective, etc.) -->
                  {#each phaseSections as section}
                    <div class="phase-md-section" class:phase-md-section--error={section.label === 'error'}>
                      <div class="phase-md-label">{section.label}</div>
                      <div class="phase-md-body">
                        <MarkdownRenderer content={section.content} />
                      </div>
                    </div>
                  {/each}

                  <!-- Per-agent run responses rendered as markdown -->
                  {#each phaseAgentRuns as run, i}
                    <div class="phase-md-section">
                      <div class="phase-md-run-header">
                        <span class="phase-md-label">{run.agentId}</span>
                        {#if run.costUsd != null}
                          <span class="phase-run-cost">${run.costUsd.toFixed(4)}</span>
                        {/if}
                        {#if run.durationMs != null}
                          <span class="phase-run-dur">{formatDuration(run.durationMs)}</span>
                        {/if}
                      </div>
                      <div class="phase-md-body">
                        <MarkdownRenderer content={run.response} />
                      </div>
                    </div>
                  {/each}

                  {#if phaseSections.length === 0 && phaseAgentRuns.length === 0 && metaStats.length === 0}
                    <div class="muted">No content available for this phase.</div>
                  {/if}
                {/if}
              </div>
            {/if}
          </div>
        {/each}
      </div>
    {/if}

    {#if activeTab === 'files'}
      <nav class="file-tabs">
        {#each FILES as f}
          <button class="file-tab" class:active={activeFile === f} onclick={() => loadFile(f)}>{f}.json</button>
        {/each}
      </nav>
      <div class="card" style="margin-top:var(--space-3);">
        {#if fileLoading[activeFile]}
          <div class="skeleton" style="height:120px;"></div>
        {:else if fileError[activeFile]}
          <div class="error-msg">{fileError[activeFile]}</div>
        {:else if fileData[activeFile] == null}
          <div class="muted">not present</div>
        {:else}
          <pre class="json">{pretty(fileData[activeFile])}</pre>
        {/if}
      </div>
    {/if}

    {#if activeTab === 'logs'}
      <div class="logs-toolbar">
        <nav class="logs-selector">
          {#each (['cli-stdout', 'tests-raw'] as const) as logName}
            <button
              class="file-tab"
              class:active={activeLog === logName}
              onclick={() => loadLog(logName)}
            >{logName}.log</button>
          {/each}
        </nav>
        <div class="logs-controls">
          <button
            class="btn btn-ghost btn-sm"
            class:active={logViewMode === 'structured'}
            onclick={() => logViewMode = 'structured'}
          >Structured</button>
          <button
            class="btn btn-ghost btn-sm"
            class:active={logViewMode === 'raw'}
            onclick={() => logViewMode = 'raw'}
          >Raw</button>
          {#if !isTerminal}
            <span class="muted" style="font-size:var(--text-xs);">
              {logStreamConnected ? '● live' : '○ connecting…'}
            </span>
          {/if}
        </div>
      </div>

      {#if logLoading[activeLog]}
        <div class="card"><div class="skeleton" style="height:200px;"></div></div>
      {:else if logError[activeLog]}
        <div class="error-msg">{logError[activeLog]}</div>
      {:else}
        {@const fullText = (logText[activeLog] ?? '') + (logStreamLines.length > 0 ? '\n' + logStreamLines.join('\n') : '')}
        {#if fullText.trim().length === 0}
          <div class="card"><div class="muted">{activeLog}.log not present yet.</div></div>
        {:else if logViewMode === 'structured'}
          {@const parsed = parseLogLines(fullText)}
          <div class="log-structured">
            {#each parsed as ln, i (i)}
              <div class="log-line log-line--{ln.level}" class:log-line--collapsed={ln.collapsed}>
                <span class="log-line-text">{ln.raw}</span>
              </div>
            {/each}
          </div>
        {:else}
          <!-- Raw mode: pre block, auto-scroll on stream -->
          <div class="log-raw-wrap" role="log" aria-live="off">
            <pre
              id="log-raw-pre"
              class="log-raw"
              onscroll={(e) => {
                const el = e.currentTarget as HTMLPreElement;
                const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
                logAutoScroll = atBottom;
              }}
            >{fullText}</pre>
          </div>
          {#if !logAutoScroll}
            <button
              class="btn btn-ghost btn-sm log-scroll-btn"
              onclick={() => {
                logAutoScroll = true;
                requestAnimationFrame(() => {
                  const el = document.getElementById('log-raw-pre');
                  if (el) el.scrollTop = el.scrollHeight;
                });
              }}
            >Resume auto-scroll</button>
          {/if}
        {/if}
      {/if}
    {/if}
  </section>
{/if}

<style>
  .stage-bar-sticky {
    position: sticky;
    top: 0;
    z-index: 10;
    background: var(--color-surface, var(--color-bg-card));
    margin-bottom: var(--space-4);
  }

  .now-playing {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    padding: var(--space-2) var(--space-5);
    background: var(--color-surface-1);
    border-top: 1px solid var(--color-border);
    border-bottom: 1px solid var(--color-border);
    font-size: var(--text-xs);
    font-family: var(--font-mono);
    color: var(--color-text-muted);
  }
  .np-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--color-info);
    animation: np-pulse 1.4s ease-in-out infinite;
    flex-shrink: 0;
  }
  @keyframes np-pulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.5; transform: scale(0.8); }
  }
  .np-phase {
    text-transform: uppercase;
    letter-spacing: 0.06em;
    font-weight: 600;
    color: var(--color-info);
  }
  .np-agent {
    color: var(--color-text);
    font-weight: 600;
  }
  .np-sep { color: var(--color-text-muted); opacity: 0.5; }
  .np-badge {
    padding: 1px 6px;
    border-radius: var(--radius-sm);
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    font-weight: 600;
  }
  .np-opus { background: rgba(168, 85, 247, 0.15); color: #c084fc; border: 1px solid rgba(168, 85, 247, 0.3); }
  .np-sonnet { background: rgba(74, 158, 255, 0.15); color: var(--color-info); border: 1px solid rgba(74, 158, 255, 0.3); }
  .np-haiku { background: rgba(76, 175, 130, 0.15); color: var(--color-success); border: 1px solid rgba(76, 175, 130, 0.3); }
  .np-effort {
    background: var(--color-surface-2);
    color: var(--color-text-muted);
    border: 1px solid var(--color-border);
  }
  .np-cost, .np-duration { color: var(--color-text); }

  .breadcrumb { margin-bottom: var(--space-2); }
  .breadcrumb a {
    font-size: var(--text-xs);
    color: var(--color-text-muted);
    text-decoration: none;
  }
  .breadcrumb a:hover { color: var(--color-text); }
  .page-title {
    display: flex;
    align-items: center;
    gap: var(--space-3);
  }

  .tabs {
    display: flex;
    gap: var(--space-1);
    border-bottom: 1px solid var(--color-border);
    margin-bottom: var(--space-4);
    flex-wrap: wrap;
  }
  .tab {
    background: transparent;
    border: none;
    color: var(--color-text-muted);
    padding: var(--space-3) var(--space-4);
    font-size: var(--text-sm);
    font-weight: 500;
    cursor: pointer;
    border-bottom: 2px solid transparent;
    transition: color var(--duration-fast), border-color var(--duration-fast);
    font-family: var(--font-sans);
  }
  .tab:hover { color: var(--color-text); }
  .tab.active {
    color: var(--color-brand);
    border-bottom-color: var(--color-brand);
  }

  .tab-panel { display: flex; flex-direction: column; gap: var(--space-4); }

  .kv {
    display: grid;
    grid-template-columns: max-content 1fr;
    gap: var(--space-2) var(--space-4);
    margin: 0;
  }
  .kv dt {
    font-size: var(--text-xs);
    color: var(--color-text-muted);
    text-transform: uppercase;
    letter-spacing: 0.06em;
  }
  .kv dd { margin: 0; font-size: var(--text-sm); }

  .mono { font-family: var(--font-mono); font-size: var(--text-xs); }
  .muted { color: var(--color-text-muted); font-size: var(--text-xs); }

  .cost-bar {
    height: 4px;
    background: var(--color-surface-2);
    border-radius: var(--radius-full);
    overflow: hidden;
  }
  .cost-bar-fill {
    height: 100%;
    background: var(--color-brand);
  }

  .pr-link { color: var(--color-info); text-decoration: none; }
  .pr-link:hover { text-decoration: underline; }

  .json {
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    background: var(--color-surface-2);
    color: var(--color-text);
    padding: var(--space-3);
    border-radius: var(--radius-md);
    overflow: auto;
    max-height: 480px;
    margin: 0;
    line-height: 1.5;
  }

  .error-banner {
    background: rgba(224,90,90,0.1);
    border: 1px solid rgba(224,90,90,0.3);
    border-radius: var(--radius-md);
    color: var(--color-danger);
    padding: var(--space-3);
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: var(--space-3);
    margin-bottom: var(--space-4);
  }
  .error-banner code {
    font-family: var(--font-mono);
    background: rgba(224,90,90,0.15);
    padding: 1px 4px;
    border-radius: 3px;
  }
  .error-msg {
    background: rgba(224,90,90,0.1);
    border: 1px solid rgba(224,90,90,0.3);
    border-radius: var(--radius-md);
    color: var(--color-danger);
    font-size: var(--text-xs);
    padding: var(--space-2) var(--space-3);
  }

  .warning-banner {
    background: rgba(245,166,35,0.1);
    border: 1px solid rgba(245,166,35,0.3);
    border-radius: var(--radius-md);
    color: var(--color-warning);
    padding: var(--space-3);
    font-size: var(--text-sm);
  }
  .warning-banner ul { margin: var(--space-2) 0 0 var(--space-4); padding: 0; }

  .summary { margin: 0; font-size: var(--text-sm); line-height: 1.6; color: var(--color-text); }

  .ranked-list { display: flex; flex-direction: column; gap: var(--space-3); }
  .rank-card {
    background: var(--color-bg-card);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    padding: var(--space-4);
  }
  .rank-header {
    display: flex;
    align-items: center;
    gap: var(--space-3);
    flex-wrap: wrap;
    margin-bottom: var(--space-2);
  }
  .rank-num {
    font-family: var(--font-mono);
    color: var(--color-text-muted);
    font-size: var(--text-sm);
    font-weight: 700;
  }
  .rank-title {
    margin: 0;
    font-size: var(--text-md);
    color: var(--color-text);
    flex: 1;
  }
  .rank-stats { display: flex; gap: var(--space-2); flex-wrap: wrap; }
  .rank-rationale {
    font-size: var(--text-sm);
    color: var(--color-text-muted);
    margin: var(--space-2) 0;
    line-height: 1.5;
  }
  .rank-meta {
    font-size: var(--text-xs);
    color: var(--color-text-muted);
    margin-top: var(--space-1);
  }
  .tag {
    display: inline-block;
    font-size: var(--text-xs);
    padding: 1px var(--space-2);
    background: var(--color-surface-2);
    border-radius: var(--radius-full);
    margin-right: var(--space-1);
    color: var(--color-text-muted);
  }

  .events-toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: var(--space-2);
  }
  .timeline {
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
  }
  .event-row {
    display: grid;
    grid-template-columns: 80px max-content 1fr;
    gap: var(--space-3);
    align-items: start;
    background: var(--color-bg-card);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    padding: var(--space-2) var(--space-3);
  }
  .event-ts { color: var(--color-text-faint); }
  .event-payload {
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    color: var(--color-text-muted);
    margin: 0;
    overflow: auto;
    max-height: 200px;
    background: transparent;
    padding: 0;
  }

  .phase-list { display: flex; flex-direction: column; gap: var(--space-2); }
  .phase-item {
    background: var(--color-bg-card);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    overflow: hidden;
  }
  .phase-toggle {
    width: 100%;
    background: transparent;
    border: none;
    color: var(--color-text);
    padding: var(--space-3);
    text-align: left;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: var(--space-3);
    font-family: var(--font-sans);
    font-size: var(--text-sm);
  }
  .phase-toggle:hover { background: var(--color-bg-card-hover); }
  .phase-toggle--open { background: var(--color-bg-card-hover); }
  .phase-arrow { color: var(--color-text-muted); font-size: var(--text-xs); }
  .phase-name {
    font-family: var(--font-mono);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    font-size: var(--text-xs);
    font-weight: 600;
    flex: 1;
  }

  /* Status dot in the phase toggle header */
  .phase-status-dot {
    width: 7px;
    height: 7px;
    border-radius: var(--radius-full);
    flex-shrink: 0;
  }
  .phase-status-dot--success  { background: var(--color-success); }
  .phase-status-dot--danger   { background: var(--color-danger); }
  .phase-status-dot--warning  { background: var(--color-warning); }
  .phase-status-dot--info     { background: var(--color-info); animation: pulse-slow 1.4s ease-in-out infinite; }
  .phase-status-dot--muted    { background: var(--color-border); }
  @keyframes pulse-slow {
    0%, 100% { opacity: 1; }
    50%       { opacity: 0.3; }
  }
  @media (prefers-reduced-motion: reduce) {
    .phase-status-dot--info { animation: none; }
  }

  /* Cost / duration chips in the toggle header */
  .phase-toggle-meta {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    margin-left: auto;
    flex-shrink: 0;
  }
  .phase-cost-chip {
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    color: var(--color-warning);
    background: rgba(245,166,35,0.08);
    border: 1px solid rgba(245,166,35,0.2);
    border-radius: var(--radius-sm);
    padding: 1px var(--space-2);
  }
  .phase-dur-chip {
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    color: var(--color-text-muted);
  }
  .phase-loading-hint,
  .phase-absent-hint {
    font-size: var(--text-xs);
    margin-left: auto;
    font-family: var(--font-mono);
  }

  .phase-body {
    padding: var(--space-3);
    border-top: 1px solid var(--color-border);
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
  }
  .phase-absent-body {
    font-size: var(--text-xs);
    font-family: var(--font-mono);
    padding: var(--space-2) 0;
  }
  .phase-runs { font-size: var(--text-xs); color: var(--color-text-muted); }

  /* Status-colored value in stat chips */
  .phase-meta-val--success  { color: var(--color-success); }
  .phase-meta-val--danger   { color: var(--color-danger); }
  .phase-meta-val--warning  { color: var(--color-warning); }

  .phase-md-section {
    border-top: 1px solid var(--color-border);
    padding-top: var(--space-3);
    display: flex;
    flex-direction: column;
    gap: var(--space-2);
  }
  /* When markdown prose is the only content (no stat chips or raw JSON above),
     the first section is the first child of .phase-body — remove the redundant
     border-top since .phase-body already provides its own top separator. */
  .phase-md-section:first-child {
    border-top: none;
    padding-top: 0;
  }
  /* Error sections get a danger accent instead of the brand blue */
  .phase-md-section--error .phase-md-body {
    border-left-color: var(--color-danger);
    background: rgba(224,90,90,0.04);
  }
  .phase-md-section--error .phase-md-label {
    color: var(--color-danger);
  }
  /* Run header: agent id label + cost/duration chips side by side */
  .phase-md-run-header {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    flex-wrap: wrap;
  }
  .phase-md-label {
    font-size: var(--text-xs);
    font-family: var(--font-mono);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: var(--color-text-muted);
  }
  /* Cost chip next to the agent id in the run header */
  .phase-run-cost {
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    color: var(--color-warning);
    background: rgba(245,166,35,0.08);
    border: 1px solid rgba(245,166,35,0.2);
    border-radius: var(--radius-sm);
    padding: 1px var(--space-2);
  }
  /* Duration chip next to the agent id in the run header */
  .phase-run-dur {
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    color: var(--color-text-muted);
  }
  /* Rendered markdown prose gets a subtle left accent strip so it reads
     clearly apart from the raw JSON block above it */
  .phase-md-body {
    background: var(--color-bg-elevated);
    border-left: 3px solid var(--color-brand);
    border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
    padding: var(--space-3) var(--space-4);
  }

  .file-tabs {
    display: flex;
    gap: var(--space-1);
    border-bottom: 1px solid var(--color-border);
    flex-wrap: wrap;
  }
  .file-tab {
    background: transparent;
    border: none;
    color: var(--color-text-muted);
    padding: var(--space-2) var(--space-3);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    cursor: pointer;
    border-bottom: 2px solid transparent;
  }
  .file-tab:hover { color: var(--color-text); }
  .file-tab.active {
    color: var(--color-brand);
    border-bottom-color: var(--color-brand);
  }

  .kill-card { border-color: rgba(224,90,90,0.4); }

  .tab-count {
    display: inline-block;
    margin-left: var(--space-2);
    padding: 0 var(--space-2);
    background: var(--color-bg-card);
    color: var(--color-text-muted);
    border-radius: 9999px;
    font-size: var(--text-xs);
    font-family: var(--font-mono);
  }

  .kanban {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: var(--space-4);
  }
  .kanban-col {
    background: var(--color-bg-elevated);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    padding: var(--space-3);
    min-height: 120px;
  }
  .kanban-header {
    font-size: var(--text-xs);
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--color-text-muted);
    padding-bottom: var(--space-2);
    margin-bottom: var(--space-2);
    border-bottom: 1px solid var(--color-border);
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .kanban-count {
    padding: 0 var(--space-2);
    background: var(--color-bg-card);
    border-radius: 9999px;
    font-family: var(--font-mono);
    font-size: var(--text-xs);
  }
  .kanban-item {
    background: var(--color-bg-card);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    padding: var(--space-3);
    margin-bottom: var(--space-2);
    transition: border-color var(--duration-fast);
  }
  .kanban-item:hover { border-color: var(--color-brand); }
  .kanban-item.in-progress { border-left: 3px solid var(--color-brand); }
  .kanban-item.completed { border-left: 3px solid var(--color-success); opacity: 0.85; }
  .kanban-item.failed { border-left: 3px solid var(--color-danger); }
  .kanban-item.killed { border-left: 3px solid var(--color-warning); opacity: 0.75; }
  .kanban-item .item-title {
    font-size: var(--text-sm);
    color: var(--color-text);
    line-height: 1.4;
    margin-bottom: var(--space-1);
  }
  .kanban-item.completed .item-title { text-decoration: line-through; color: var(--color-text-muted); }
  .kanban-item .item-meta {
    font-size: var(--text-xs);
    color: var(--color-text-muted);
    font-family: var(--font-mono);
  }

  .agent-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    gap: var(--space-3);
  }
  .agent-summary { padding: var(--space-3); }
  .agent-name {
    font-family: var(--font-mono);
    font-weight: 700;
    font-size: var(--text-md);
    color: var(--color-text);
    margin-bottom: var(--space-2);
  }
  .agent-stats {
    display: flex;
    gap: var(--space-4);
    font-size: var(--text-sm);
    margin-bottom: var(--space-2);
  }
  .agent-phases { display: flex; flex-wrap: wrap; gap: var(--space-1); }
  .phase-chip {
    padding: 2px var(--space-2);
    background: var(--color-bg-card);
    border: 1px solid var(--color-border);
    border-radius: 9999px;
    font-size: var(--text-xs);
    font-family: var(--font-mono);
    color: var(--color-text-muted);
  }

  .run-list { display: flex; flex-direction: column; gap: var(--space-2); }
  .run-row { padding: var(--space-3); }
  .run-row.failed { border-left: 3px solid var(--color-danger); }
  .run-header {
    display: flex;
    gap: var(--space-3);
    align-items: center;
    margin-bottom: var(--space-1);
    font-size: var(--text-sm);
    flex-wrap: wrap;
  }
  .run-phase {
    font-size: var(--text-xs);
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--color-text-muted);
    font-weight: 700;
  }
  .run-agent { color: var(--color-brand); font-weight: 600; }
  .run-status {
    padding: 2px var(--space-2);
    border-radius: 9999px;
    font-size: var(--text-xs);
    font-family: var(--font-mono);
  }
  .run-status.completed { background: rgba(76,175,130,0.15); color: var(--color-success); }
  .run-status.failed { background: rgba(224,90,90,0.15); color: var(--color-danger); }
  .run-item { font-size: var(--text-xs); font-family: var(--font-mono); }
  .model-chip {
    padding: 2px var(--space-2);
    border-radius: 9999px;
    font-size: var(--text-xs);
    font-family: var(--font-mono);
    font-weight: 600;
    border: 1px solid currentColor;
  }
  .model-chip[class*="opus"] { color: var(--color-opus, #f5c842); background: rgba(245,200,66,0.08); }
  .model-chip[class*="sonnet"] { color: var(--color-sonnet, #4a9eff); background: rgba(74,158,255,0.08); }
  .model-chip[class*="haiku"] { color: var(--color-haiku, #4cb071); background: rgba(76,175,130,0.08); }
  .effort-chip {
    padding: 2px var(--space-2);
    border-radius: 9999px;
    font-size: var(--text-xs);
    font-family: var(--font-mono);
    color: var(--color-text-muted);
    background: var(--color-bg-card);
    border: 1px solid var(--color-border);
  }
  .run-meta {
    display: flex;
    gap: var(--space-2);
    font-size: var(--text-xs);
    color: var(--color-text-muted);
    font-family: var(--font-mono);
    margin-bottom: var(--space-2);
  }
  .run-error {
    background: rgba(224,90,90,0.08);
    padding: var(--space-2);
    border-radius: var(--radius-sm);
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    color: var(--color-danger);
  }
  .run-response summary {
    cursor: pointer;
    font-size: var(--text-xs);
    color: var(--color-text-muted);
    padding: var(--space-1) 0;
  }
  .run-response-body {
    margin-top: var(--space-2);
    padding: var(--space-3);
    background: var(--color-bg-elevated);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    max-height: 480px;
    overflow: auto;
  }
  .run-response-truncated {
    margin: var(--space-2) 0 0;
    font-size: var(--text-xs);
    color: var(--color-text-faint);
    font-family: var(--font-mono);
  }

  /* Phase metadata stat chips */
  .phase-meta-stats {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-2);
  }
  .phase-meta-stat {
    display: flex;
    align-items: center;
    gap: var(--space-1);
    background: var(--color-bg-elevated);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    padding: var(--space-1) var(--space-2);
  }
  .phase-meta-key {
    font-size: var(--text-xs);
    font-family: var(--font-mono);
    color: var(--color-text-muted);
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }
  .phase-meta-val {
    font-size: var(--text-xs);
    font-family: var(--font-mono);
    font-weight: 700;
    color: var(--color-text);
  }

  /* Collapsible raw JSON block within phases */
  .phase-json-details {
    display: flex;
    flex-direction: column;
    gap: var(--space-1);
  }
  .phase-json-summary {
    cursor: pointer;
    font-size: var(--text-xs);
    font-family: var(--font-mono);
    color: var(--color-text-muted);
    user-select: none;
    padding: var(--space-1) 0;
  }
  .phase-json-summary:hover { color: var(--color-text); }

  @media (max-width: 700px) {
    .event-row { grid-template-columns: 1fr; }
  }

  /* Logs tab */
  .logs-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--space-3);
    flex-wrap: wrap;
    margin-bottom: var(--space-3);
  }
  .logs-selector {
    display: flex;
    gap: var(--space-1);
    border-bottom: 1px solid var(--color-border);
  }
  .logs-controls {
    display: flex;
    align-items: center;
    gap: var(--space-2);
  }
  .btn.active {
    color: var(--color-brand);
    background: rgba(var(--color-brand-rgb, 99,102,241), 0.08);
  }

  .log-structured {
    display: flex;
    flex-direction: column;
    gap: 1px;
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    background: var(--color-surface-2);
    border-radius: var(--radius-md);
    overflow: auto;
    max-height: 600px;
    padding: var(--space-2);
  }
  .log-line {
    padding: 1px var(--space-2);
    border-radius: 2px;
    line-height: 1.5;
    white-space: pre-wrap;
    word-break: break-all;
  }
  .log-line--info { color: var(--color-text-muted); }
  .log-line--warn { color: var(--color-warning); background: rgba(245,166,35,0.06); }
  .log-line--error { color: var(--color-danger); background: rgba(224,90,90,0.08); font-weight: 600; }
  .log-line--collapsed { color: var(--color-text-faint); font-style: italic; }
  .log-line-text { white-space: pre-wrap; word-break: break-all; }

  .log-raw-wrap {
    position: relative;
    background: var(--color-surface-2);
    border-radius: var(--radius-md);
    overflow: hidden;
  }
  .log-raw {
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    color: var(--color-text-muted);
    padding: var(--space-3);
    overflow: auto;
    max-height: 600px;
    margin: 0;
    line-height: 1.5;
    white-space: pre-wrap;
    word-break: break-all;
  }
  .log-scroll-btn {
    margin-top: var(--space-2);
    display: block;
    margin-left: auto;
  }

  .tab-live-dot {
    display: inline-block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--color-success);
    margin-left: var(--space-1);
    animation: pulse-slow 1.4s ease-in-out infinite;
    vertical-align: middle;
  }
</style>
